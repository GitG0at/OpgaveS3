/*const element = document.querySelector('form');
element.addEventListener('submit', event => {
  event.preventDefault();
  // actual logic, e.g. validate the form
  console.log('Form submission cancelled.');
});*/

const app = Vue.createApp({
    data:function(){
        return{
            active:false,
            items: ['name1','name2','name3'],
            headtext: "Enter Imput"
        }
    },
    methods:{
      //
      SaveInput(){
        let id = document.getElementById('finputdata');
        this.items[0] = id.value;
        this.items[1] = id.value.toLowerCase();
        this.items[2] = id.value.toUpperCase();
        this.active = true;
        if(this.items[0] == this.items[2]){
          this.headtext = "Imput is UpperCase";
        }else{
          this.headtext = "Imput is Mixed";
        }
        if(this.items[0] == this.items[1]){
          if(this.items[0] == this.items[2]){
            this.headtext = "Imput is not text";
          }else{
            this.headtext = "Imput is LowerCase";
          }
        }
      },
      addToList(){
        
        
      }
    }
})