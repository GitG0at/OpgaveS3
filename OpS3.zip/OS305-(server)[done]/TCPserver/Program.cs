﻿using OpgaveAS301;
using System;
using System.Collections.Generic;

namespace TCPserver
{
    public class Program
    {
        public static List<FootballPlayer> Jitem_Players;
        public static void Main(string[] args)
        {
            Jitem_Players = new List<FootballPlayer>();
            //Debug start
            for (int i = 0; i < 10; i++)
            {
                Jitem_Players.Add(
                     new FootballPlayer(i, "player" + i,Math.Abs((5-i) * 100), i*10));
            }
            //Debug end

            MyTCPServer tcpS = new MyTCPServer();
            tcpS.Start(2121);
        }
    }
}
