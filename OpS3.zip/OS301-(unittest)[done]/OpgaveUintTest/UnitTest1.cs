using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpgaveAS301;
namespace OpgaveUintTest
{
    [TestClass]
    public class UnitTest1
    {
        private FootballPlayer TestClass = new FootballPlayer();
        //[TestInitialize]


        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(20)]
        public void TestForID_pass(object value)
        {
            TestClass.id = value;
            Assert.IsNotNull(TestClass.id);
        }
        [TestMethod]
        [DataRow("fisk")]
        [DataRow(2.2)]
        public void TestForID_fail(object value)
        {
            try
            {
                TestClass.id = value;
            }
            catch (System.Exception)
            {
                return;
            }
            Assert.Fail();
        }
        [TestMethod]
        [DataRow(1)]
        [DataRow(44)]
        [DataRow(100)]
        public void TestForShirtNumber_pass(object value)
        {
            try
            {
                TestClass.shirtNumber = value;
            }
            catch (System.Exception)
            {
                Assert.Fail();
            }
            Assert.IsNotNull(TestClass.shirtNumber);
        }
        [TestMethod]
        [DataRow("fisk")]
        [DataRow(2.2)]
        [DataRow(200)]
        [DataRow(-10)]
        public void TestForShirtNumber_fail(object value)
        {
            try
            {
                TestClass.shirtNumber = value;
            }
            catch (System.Exception)
            {
                return;
            }
            Assert.Fail();
        }
        [TestMethod]
        [DataRow("fisk")]
        [DataRow("fakefisk")]
        public void TestForName_pass(string value)
        {
            try
            {
                TestClass.name = value;
            }
            catch (System.Exception)
            {
                Assert.Fail();
            }
            Assert.IsNotNull(TestClass.shirtNumber);
        }
        [TestMethod]
        [DataRow("f")]
        [DataRow("fak")]
        [DataRow("")]
        public void TestForName_fail(string value)
        {
            try
            {
                TestClass.name = value;
            }
            catch (System.Exception)
            {
                return;
            }
            Assert.Fail();
        }
        [TestMethod]
        [DataRow(1)]
        [DataRow(440000)]

        public void TestForPrice_pass(object value)
        {
            try
            {
                TestClass.price = value;
            }
            catch (System.Exception)
            {
                Assert.Fail();
            }
            Assert.IsNotNull(TestClass.shirtNumber);
        }
        [TestMethod]
        [DataRow(0)]
        [DataRow(-440000)]
        public void TestForPrice_fail(object value)
        {
            try
            {
                TestClass.price = value;
            }
            catch (System.Exception)
            {
                return;
            }
            Assert.Fail();
        }
        /*
         *  [DataRow(1.2)]
     
       
        [DataRow("fisk")]
      
        public void TestForShirtNumber(object value)
        {
            TestClass.ShirtNumber = value;
            Assert.IsNotNull(TestClass.ShirtNumber);
        }
        */


    }
}
